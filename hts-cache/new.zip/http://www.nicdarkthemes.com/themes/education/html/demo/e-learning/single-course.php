<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<head>
 
    <meta charset="utf-8">  
    
    <title>Education - Learning Theme</title> <!--insert your title here-->  
    <meta name="description" content="Education - Learning theme for your business"> <!--insert your description here-->  
    <meta name="author" content="nicdark"> <!--insert your name here-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--meta responsive-->
    
    <!--START CSS--> 
    <link rel="stylesheet" href="css/nicdark_style.min.css"> <!--style-->

    <!--google fonts-->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

    <!--[if lt IE 9]>  
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>  
    <![endif]-->  

    <!--FAVICONS-->
    <link rel="shortcut icon" href="img/favicon/favicon.ico">
    <link rel="apple-touch-icon" href="img/favicon/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-touch-icon-114x114.png">
    <!--END FAVICONS-->
    
    
</head>  
    <body id="start_nicdark_framework">


        <!--START for demo-->
            <!--btn purchase-->
            <div class="nicdark_bg_greydark nicdark_z_index_99 nicdark_padding_1020 nicdark_border_radius_3 nicdark_position_fixed nicdark_bottom_20 nicdark_right_20">
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><img alt="" class="nicdark_float_left nicdark_margin_right_10" width="15" src="img/icons/icon-cart-white.svg"></a>
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><p class=" nicdark_first_font nicdark_line_height_17 nicdark_color_white nicdark_font_size_14 nicdark_float_left">Buy <strong>Education</strong> On</p></a>
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><img alt="" class="nicdark_float_left nicdark_margin_left_10" width="70" src="img/demo/envatologo.jpg"></a>
            </div>
            <!--END btn purchase-->
        <!--END for demo-->


        <!--START nicdark_site-->
        <div class="nicdark_site">

            <!--START nicdark_site_fullwidth-->
            <div class="nicdark_site_fullwidth nicdark_site_fullwidth_boxed nicdark_clearfix">








                <!--START search container-->
<div class="nicdark_display_table nicdark_transition_all_08_ease nicdark_navigation_2_search_content nicdark_bg_greydark_alpha_9 nicdark_position_fixed nicdark_width_100_percentage nicdark_height_100_percentage nicdark_z_index_1_negative nicdark_opacity_0">

    <!--close-->
    <div class="nicdark_cursor_zoom_out nicdark_navigation_2_close_search_content nicdark_width_100_percentage nicdark_height_100_percentage nicdark_position_absolute nicdark_z_index_1_negative"></div>


    <div class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_text_align_center">
        <div class="nicdark_width_700 nicdark_width_250_all_iphone nicdark_display_inline_block">
            <div class="nicdark_width_80_percentage nicdark_padding_5 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                <input class="nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0 nicdark_first_font nicdark_color_white nicdark_placeholder_color_white nicdark_font_size_30 nicdark_line_height_30" type="text" placeholder="Search">
            </div>
            <div class="nicdark_width_20_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                <a class="nicdark_width_55 nicdark_height_55 nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_bg_yellow nicdark_padding_15 nicdark_border_radius_3 " href="courses.php">
                    <img alt="" width="25" src="img/icons/icon-search-white.svg">
                </a>   
            </div>
        </div>
    </div>
            


</div>
<!--END search container-->




<!--START menu responsive-->
<div class="nicdark_navigation_2_sidebar_content nicdark_padding_40 nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_y_auto nicdark_transition_all_08_ease nicdark_bg_yellow nicdark_height_100_percentage nicdark_position_fixed nicdark_width_300 nicdark_right_300_negative nicdark_z_index_9">

    <img alt="" width="25" class="nicdark_close_navigation_2_sidebar_content nicdark_cursor_pointer nicdark_right_20 nicdark_top_20 nicdark_position_absolute" src="img/icons/icon-close-white.svg">



    <div class="nicdark_navigation_2_sidebar">
        <ul>
            <li>
                <a href="index.php">HOME</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="index.php">Home 1</a></li>
                    <li><a href="index-2.php">Home 2</a></li>
                    <li><a href="index-3.php">Home 3</a></li>
                    <li><a href="index-4.php">Home 4</a></li>
                    <li><a href="index-5.php">Home 5</a></li>
                </ul>

            </li>
            <li>
                <a href="courses.php">COURSES</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="courses.php">Archive</a></li>
                    <li><a href="single-course.php">Single Course</a></li>
                    <li>
                        <a href="account.php">User Pages</a>

                        <ul class="nicdark_sub_menu">
                            <li><a href="account.php">My Account</a></li> 
                            <li><a href="compare.php">Compare</a></li>
                        </ul>

                    </li> 
                    <li>
                        <a href="courses.php">Shop</a>

                        <ul class="nicdark_sub_menu">
                            <li><a href="cart.php">Cart</a></li>
                            <li><a href="checkout.php">Checkout</a></li>
                            <li><a href="thankyou.php">Thank You</a></li>
                        </ul>

                    </li> 
                </ul>

            </li>
            <li>
                <a href="teachers.php">TEACHERS</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="teachers.php">Archive</a></li>
                    <li><a href="single-teacher.php">Single Teacher</a></li>
                </ul>

            </li>
            <li>
                <a href="#">PAGES</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="single-course.php">Single Course</a></li>
                    <li><a href="single-teacher.php">Single Teacher</a></li>
                    <li><a href="contact-1.php">Contact</a></li>
                </ul>

            </li>
            <li>
                <a href="blog-standard.php">BLOG</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="blog-standard.php">Archive Standard</a></li>
                    <li><a href="blog-masonry.php">Archive Masonry</a></li>
                    <li><a href="single.php">Post Right Sidebar</a></li>
                    <li><a href="single-full-width.php">Post Full Width</a></li>
                    <li><a href="single-left-sidebar.php">Post Left Sidebar</a></li>
                </ul>

            </li>
            <li>
                <a href="contact-1.php">CONTACT</a>
            </li>
            
        </ul>

    </div>



</div>
<!--END menu responsive-->





<div class="nicdark_section">

    <div class="nicdark_section nicdark_bg_greydark">

        


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="grid grid_6 nicdark_padding_botttom_10 nicdark_padding_top_10 nicdark_text_align_center_responsive">

              
                <div class="nicdark_navigation_top_header_2">
                    <ul>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 " width="15" src="img/icons/icon-world-grey.svg">
                            <a class=" nicdark_line_height_18" href="#">LANGUAGES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="#">English</a></li>
                                <li><a href="#">Russian</a></li>
                                <li><a href="#">Italian</a></li>
                            </ul>

                        </li>
                        <li>
                            
                            <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-share-grey.svg">
                            <a class=" nicdark_line_height_18" href="#">OUR SOCIAL</a>

                            <ul class="nicdark_sub_menu">
                                <li><a target="_blank" href="https://www.facebook.com/cleanthemeslab">Facebook</a></li>
                                <li><a target="_blank" href="https://dribbble.com/cleanthemeslab">Dribbble</a></li>
                                <li><a target="_blank" href="https://twitter.com/cleanthemeslab">Twitter</a></li>
                                <li><a target="_blank" href="https://www.instagram.com/cleanthemeslab/">Instagram</a></li>
                                <li><a target="_blank" href="https://www.behance.net/cleanthemeslab">Behance</a></li>
                            </ul>

                            <a target="_blank" href="https://www.facebook.com/cleanthemeslab"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-facebook-grey.svg"></a>
                            <a target="_blank" href="https://twitter.com/cleanthemeslab"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-twitter-grey.svg"></a>
                            <a target="_blank" href="#"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-linkedin-grey.svg"></a>
                            <a target="_blank" href="#"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-pinterest-grey.svg"></a>
                            <a target="_blank" href="https://www.instagram.com/cleanthemeslab/"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-instagram-grey.svg"></a>

                        </li>
                    </ul>
                </div>
                

            </div>


            <div class="grid grid_6 nicdark_text_align_right nicdark_border_top_1_solid_greydark_responsive nicdark_text_align_center_responsive nicdark_padding_botttom_10 nicdark_padding_top_10">

              
                <div class="nicdark_navigation_top_header_2">
                    <ul>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 nicdark_float_left" width="15" src="img/icons/icon-user-grey.svg">
                            <a href="#">LOGIN</a>
                        </li>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 nicdark_float_left" width="15" src="img/icons/icon-login-grey.svg">
                            <a href="#">REGISTER</a>
                        </li>
                    </ul>
                </div>
                

            </div>


        </div>
        <!--end container-->

    </div>

</div>

<div class="nicdark_section nicdark_position_relative ">

    <div class="nicdark_section nicdark_position_absolute">

        


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_position_relative">

            <div class="grid grid_12 nicdark_display_none_all_responsive">

                <div class="nicdark_section nicdark_height_10"></div>

                <!--LOGO-->
                <a href="index.php"><img alt="" class="nicdark_position_absolute nicdark_left_15 nicdark_top_20" width="170" src="img/logos/logo-elearning-white.svg"></a>
              

                <!--right icons menu-->
                <div class="nicdark_float_right nicdark_width_100  nicdark_position_relative nicdark_height_25 nicdark_display_none_all_responsive">
                    
                    <a href="cart.php">
                        <img alt="" class="nicdark_opacity_05_hover nicdark_transition_all_08_ease nicdark_position_absolute nicdark_top_3_negative nicdark_left_0 nicdark_margin_left_20" width="25" src="img/icons/icon-cart-white.svg">
                    </a>

                    <a class="nicdark_bg_yellow nicdark_color_white nicdark_padding_5 nicdark_border_radius_100_percentage nicdark_font_size_8 nicdark_line_height_5 nicdark_position_absolute nicdark_left_0 nicdark_top_10_negative nicdark_margin_left_40" href="#">2</a>

                    <a class="nicdark_navigation_2_open_search_content" href="#"><img alt="" class="nicdark_opacity_05_hover nicdark_transition_all_08_ease nicdark_position_absolute nicdark_top_3_negative nicdark_right_0" width="25" src="img/icons/icon-search-white.svg"></a>

                </div>
                <!--right icons menu-->


                <div class="nicdark_navigation_2 nicdark_text_align_right nicdark_float_right nicdark_display_none_all_responsive">
                    <ul>
                        <li>
                            <a href="index.php">HOME</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="index.php">Home 1</a></li>
                                <li><a href="index-2.php">Home 2</a></li>
                                <li><a href="index-3.php">Home 3</a></li>
                                <li><a href="index-4.php">Home 4</a></li>
                                <li><a href="index-5.php">Home 5</a></li>
                            </ul>
                            
                        </li>
                        <li>
                            <a href="courses.php">COURSES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="courses.php">Archive</a></li>
                                <li><a href="single-course.php">Single Course</a></li>
                                <li>
                                    <a href="account.php">User Pages</a>

                                    <ul class="nicdark_sub_menu">
                                        <li><a href="account.php">My Account</a></li> 
                                        <li><a href="compare.php">Compare</a></li>
                                    </ul>

                                </li> 
                                <li>
                                    <a href="courses.php">Shop</a>

                                    <ul class="nicdark_sub_menu">
                                        <li><a href="cart.php">Cart</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="thankyou.php">Thank You</a></li>
                                    </ul>

                                </li> 
                            </ul>

                        </li>
                        <li>
                            <a href="teachers.php">TEACHERS</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="teachers.php">Archive</a></li>
                                <li><a href="single-teacher.php">Single Teacher</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="#">PAGES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li><a href="single-course.php">Single Course</a></li>
                                <li><a href="single-teacher.php">Single Teacher</a></li>
                                <li><a href="contact-1.php">Contact</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="blog-standard.php">BLOG</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="blog-standard.php">Archive Standard</a></li>
                                <li><a href="blog-masonry.php">Archive Masonry</a></li>
                                <li><a href="single.php">Post Right Sidebar</a></li>
                                <li><a href="single-full-width.php">Post Full Width</a></li>
                                <li><a href="single-left-sidebar.php">Post Left Sidebar</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="contact-1.php">CONTACT</a>
                        </li>
                        
                    </ul>

                </div> 


                

                <div class="nicdark_section nicdark_height_10"></div> 
                
            </div>




            <!--RESPONSIVE-->
            <div class="nicdark_width_50_percentage nicdark_text_align_center_all_iphone nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_display_none nicdark_display_block_responsive">
                <div class="nicdark_section nicdark_height_20"></div>
                <a href="index.php"><img alt="" width="170" class="" src="img/logos/logo-elearning-white.svg"></a>   
            </div>
            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_display_none nicdark_display_block_responsive">
                <div class="nicdark_section nicdark_height_20"></div>
                <div class="nicdark_float_right nicdark_width_100_percentage nicdark_text_align_right nicdark_text_align_center_all_iphone">
                    
                    
                    <a class="nicdark_open_navigation_2_sidebar_content" href="#">
                        <img alt="" class="nicdark_margin_right_20" width="25" src="img/icons/icon-menu-white.svg">
                    </a>

                    <div class="nicdark_position_relative nicdark_display_inline_block">
                        <a href="cart.php"><img alt="" width="25" src="img/icons/icon-cart-white.svg"></a> 
                        <a class="nicdark_bg_yellow nicdark_color_white nicdark_padding_5 nicdark_border_radius_100_percentage nicdark_font_size_8 nicdark_line_height_5 nicdark_position_absolute nicdark_left_0 nicdark_top_10_negative nicdark_margin_left_20" href="#">2</a>
                    </div>

                    <img alt="" class="nicdark_margin_left_20 nicdark_navigation_2_open_search_content" width="25" src="img/icons/icon-search-white.svg"> 

                </div>
            </div>
            <!--RESPONSIVE-->





        </div>
        <!--end container-->

    </div>

</div>





                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img17.jpg);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>


                            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left">

                                
                                
                                <strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">Learn the Web Design Basics </strong>

                                <div class="nicdark_section nicdark_height_20"></div>


                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="30" src="img/icons/icon-calendar.svg">
                                    <h3 class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle">21 / 12 / 2017</h3>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="30" src="img/icons/icon-clock.svg">
                                    <h3 class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle ">8 Hours</h3>
                                </div>


                                <div class="nicdark_section nicdark_height_20"></div>
                                

                            </div>




                            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_display_none_all_iphone nicdark_float_left nicdark_text_align_right">

                                <div class="nicdark_section nicdark_height_40"></div>

                            
                                <div class="nicdark_display_table nicdark_float_right">

                                    <div class="nicdark_display_table_cell nicdark_vertical_align_bottom">
                                        <h5 class="nicdark_font_size_20 nicdark_color_white">per person / </h5>
                                    </div>
                                            
                                    <div class="nicdark_display_table_cell nicdark_vertical_align_top">
                                        <h5 class="nicdark_font_size_20 nicdark_color_white nicdark_margin_5">$</h5>
                                    </div>

                                    <div class="nicdark_display_table_cell nicdark_vertical_align_bottom">
                                        <h1 class=" nicdark_color_white nicdark_font_size_60 nicdark_line_height_50">65</h1>
                                    </div>

                                </div> 


                            </div>




                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                    <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                            <div class="grid grid_12">


                                
                                <a href="#">Home</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Courses</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Web Design</a>
                                


                            </div>

                    
                        </div>
                        <!--end container-->

                    </div>




                    <div class="nicdark_section nicdark_height_50"></div>



                    <div class="nicdark_section">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                            <div class="nicdark_width_66_percentage nicdark_width_100_percentage_ipad_port nicdark_width_100_percentage_all_iphone nicdark_float_left">

                                <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                                
                                    <h1>Learn the Web Design Basics</h1>
                                    <div class="nicdark_section nicdark_height_20"></div>


                                    <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left">
                                        <div class="nicdark_display_table nicdark_float_left">
                                            
                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                <img alt="" class="nicdark_margin_right_10 nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-1.jpg">
                                            </div>

                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                <p class="nicdark_font_size_13">Teacher</p>
                                                <div class="nicdark_section nicdark_height_5"></div>
                                                <h5 class="">Jane Doe</h5>
                                            </div>

                                        </div> 
                                    </div>
                                    <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left">

                                        <div class="nicdark_section nicdark_height_5"></div>
                                        <div class="nicdark_display_table nicdark_float_left">
                                            
                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                <img alt="" class="nicdark_margin_right_10" width="30" src="img/icons/icon-category-grey.svg">
                                            </div>

                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                <p class="nicdark_font_size_13">Category</p>
                                                <div class="nicdark_section nicdark_height_5"></div>
                                                <h5 class="">Web Design</h5>
                                            </div>

                                        </div> 
                                    </div>
                                    
                                    <div class="nicdark_width_50_percentage nicdark_display_none_all_iphone nicdark_float_right">

                                        <div class="nicdark_section nicdark_height_5"></div>
                                        <div class="nicdark_section nicdark_height_5"></div>
                                        
                                        <div class="nicdark_display_table nicdark_float_right">
                                            <a href="#"><img alt="" class="" width="30" src="img/icons/icon-print-grey.svg"></a>
                                        </div> 
                                    </div>
                                    


                                    <div class="nicdark_section nicdark_height_20"></div>
                                    


                                    <div class="nicdark_section nicdark_position_relative">
                                            
                                        <img alt="" class="nicdark_section" src="img/courses/img20.jpg">

                                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                                
                                                <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_color_white nicdark_border_1_solid_white nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_right_20" href="account.php#tabs-3">BOOKMARK</a>
                                                <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_color_white nicdark_border_1_solid_white nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 " href="compare.php">COMPARE</a>

                                            </div>

                                        </div>

                                    </div>



                                    <div class="nicdark_section nicdark_height_40"></div>


                                    <div class="nicdark_section">


                                        <!--START tab-->
                                        <div class="nicdark_tabs">
                                            <ul class="nicdark_list_style_none nicdark_margin_0 nicdark_padding_0 nicdark_section nicdark_border_bottom_2_solid_grey">
                                                <li class="nicdark_display_inline_block"><h4><a class="nicdark_outline_0 nicdark_padding_20 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark" href="#tabs-1">Descriptions</a></h4></li>
                                                <li class="nicdark_display_inline_block"><h4><a class="nicdark_outline_0 nicdark_padding_20 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark" href="#tabs-2">Program</a></h4></li>
                                                <li class="nicdark_display_inline_block"><h4><a class="nicdark_outline_0 nicdark_padding_20 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark" href="#tabs-3">Teachers</a></h4></li>
                                                <li class="nicdark_display_inline_block"><h4><a class="nicdark_outline_0 nicdark_padding_20 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark" href="#tabs-4">Comment</a></h4></li>
                                                <li class="nicdark_display_inline_block"><h4><a class="nicdark_outline_0 nicdark_padding_20 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark" href="#tabs-5">Reviews</a></h4></li>
                                                <li class="nicdark_display_inline_block"><h4><a class="nicdark_outline_0 nicdark_padding_20 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark" href="#tabs-6">Attendees</a></h4></li>
                                            </ul>

                                            <div class="nicdark_section nicdark_height_40"></div>

                                            <div class="nicdark_section" id="tabs-1">

                                                <h3><strong>Course Description</strong></h3>
                                                <div class="nicdark_section nicdark_height_20"></div>
                                                <p>Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus. Vivamus bibendum nibh in dolor pharetra, a euismod nulla dignissim. Aenean viverra tincidunt nibh, in imperdiet nunc. Suspendisse eu ante pretium, consectetur leo at, congue quam. Nullam hendrerit porta ante vitae tristique. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum ligula libero, feugiat faucibus mattis eget, pulvinar et ligula.</p>
                                                <div class="nicdark_section nicdark_height_40"></div>
                                                <h3><strong>Requirements</strong></h3>
                                                <div class="nicdark_section nicdark_height_20"></div>
                                                <p>Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus. Vivamus bibendum nibh in dolor pharetra, a euismod nulla dignissim. Aenean viverra tincidunt nibh, in imperdiet nunc. Suspendisse eu ante pretium, consectetur leo at, congue quam. Nullam hendrerit porta ante vitae tristique. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum ligula libero, feugiat faucibus mattis eget, pulvinar et ligula.</p>
                                                <div class="nicdark_section nicdark_height_50"></div>
                                                
                                                <!--start tag-->
                                                <div class="nicdark_section">
                                                    <a class="nicdark_display_inline_block nicdark_padding_8 nicdark_first_font nicdark_margin_right_10 nicdark_color_greydark nicdark_padding_left_0" href="#">Tag :</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Web</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Lessons</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#">Learning</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#">Students</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># ecommerce</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Computer</a>
                                                    <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#">elearning</a>
                                                </div>
                                                <!--end tag-->

                                                <div class="nicdark_section nicdark_height_30"></div>

                                                <!--start social-->
                                                <div class="nicdark_section">
                                                    <a href="#"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-facebook-color.svg"></a>
                                                    <a href="#"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-twitter-color.svg"></a>
                                                    <a href="#"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-color.svg"></a>
                                                    <a href="#"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-color.svg"></a>
                                                    <a href="#"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-google-color.svg"></a>
                                                    <a href="#"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-mail-color.svg"></a>
                                                </div>
                                                <!--end-->

                                            </div>
                                            <div class="nicdark_section" id="tabs-2">

                                                <!--START program-->
                                                <h3><strong>Our Program</strong></h3>
                                                <div class="nicdark_section nicdark_height_30"></div>

                                                <div class="nicdark_section">


                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_15 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_width_15_percentage nicdark_width_100_percentage_responsive nicdark_float_left">
                                                            <table>
                                                                <tr>
                                                                    <td><img alt="" width="20" src="img/icons/icon-file-green.svg"></td>
                                                                    <td><span class="nicdark_color_grey nicdark_first_font nicdark_font_size_12 nicdark_margin_left_10">LESSON</span></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                        <div class="nicdark_width_75_percentage nicdark_width_100_percentage_responsive nicdark_float_left">
                                                            <h4 class="nicdark_padding_5 nicdark_second_font">Introducing the Html basics</h4>
                                                        </div>
                                                        <div class="nicdark_width_10_percentage nicdark_width_100_percentage_responsive nicdark_float_left nicdark_text_align_right nicdark_text_align_left_responsive nicdark_margin_top_5_responsive">
                                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">PREVIEW</a>
                                                        </div>
                                                    </div>

                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_15 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_width_15_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

                                                            <table>
                                                                <tr>
                                                                    <td><img alt="" width="20" src="img/icons/icon-file-green.svg"></td>
                                                                    <td><span class="nicdark_color_grey nicdark_first_font nicdark_font_size_12 nicdark_margin_left_10">PDF</span></td>
                                                                </tr>
                                                            </table>

                                                        </div>
                                                        <div class="nicdark_width_75_percentage nicdark_width_100_percentage_responsive nicdark_float_left">
                                                            <h4 class="nicdark_padding_5 nicdark_second_font">Download course slides</h4>
                                                        </div>
                                                        <div class="nicdark_width_10_percentage nicdark_width_100_percentage_responsive nicdark_float_left nicdark_text_align_right nicdark_text_align_left_responsive nicdark_margin_top_5_responsive">
                                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">PREVIEW</a>
                                                        </div>
                                                    </div>

                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_15 nicdark_box_sizing_border_box ">
                                                        <div class="nicdark_width_15_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

                                                            <table>
                                                                <tr>
                                                                    <td><img alt="" width="20" src="img/icons/icon-play-green.svg"></td>
                                                                    <td><span class="nicdark_color_grey nicdark_first_font nicdark_font_size_12 nicdark_margin_left_10">VIDEO</span></td>
                                                                </tr>
                                                            </table>

                                                        </div>
                                                        <div class="nicdark_width_75_percentage nicdark_width_100_percentage_responsive nicdark_float_left">
                                                            <h4 class="nicdark_padding_5 nicdark_second_font">Create a WebSite</h4>
                                                        </div>
                                                        <div class="nicdark_width_10_percentage nicdark_width_100_percentage_responsive nicdark_float_left nicdark_text_align_right nicdark_text_align_left_responsive nicdark_margin_top_5_responsive">
                                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">PREVIEW</a>
                                                        </div>
                                                    </div>


                                                </div>

                                                <!--END program-->

                                            </div>
                                            <div class="nicdark_section" id="tabs-3">



                                                <h3><strong>Our Main Teachers</strong></h3>
                                                <div class="nicdark_section nicdark_height_30"></div>

                                                <div class="nicdark_section">



                                                    <!--START teacher-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">


                                                        <div class="nicdark_display_table nicdark_float_left">
                                                                    
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                                <img alt="" class="nicdark_width_50_all_iphone nicdark_margin_right_20 nicdark_border_radius_100_percentage " width="100" src="img/avatar/avatar-chef-2.jpg">
                                                            </div>

                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                                <h3 class=""><strong>Linda Doe</strong></h3>
                                                                <div class="nicdark_section nicdark_height_5"></div>
                                                                <h5 class="nicdark_color_grey">Web Design Teacher</h5>
                                                                <div class="nicdark_section nicdark_height_20"></div>

                                                                <div class="nicdark_section">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-facebook-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-twitter-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-color.svg">
                                                                </div>

                                                            </div>

                                                        </div>
                                                
                                                        <div class="nicdark_section nicdark_height_20"></div>

                                                        <p class="nicdark_section">Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum. </p>
                                                        

                                                    </div>
                                                    <!--END teacher-->



                                                    <!--START teacher-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">


                                                        <div class="nicdark_display_table nicdark_float_left">
                                                                    
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                                <img alt="" class="nicdark_width_50_all_iphone nicdark_margin_right_20 nicdark_border_radius_100_percentage " width="100" src="img/avatar/avatar-chef-3.jpg">
                                                            </div>

                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                                <h3 class=""><strong>John Rightness</strong></h3>
                                                                <div class="nicdark_section nicdark_height_5"></div>
                                                                <h5 class="nicdark_color_grey">Html Teacher</h5>
                                                                <div class="nicdark_section nicdark_height_20"></div>

                                                                <div class="nicdark_section">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-facebook-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-twitter-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-color.svg">
                                                                </div>

                                                            </div>

                                                        </div>
                                                
                                                        <div class="nicdark_section nicdark_height_20"></div>

                                                        <p class="nicdark_section">Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum. </p>
                                                        

                                                    </div>
                                                    <!--END teacher-->



                                                    <!--START teacher-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">


                                                        <div class="nicdark_display_table nicdark_float_left">
                                                                    
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                                <img alt="" class="nicdark_width_50_all_iphone nicdark_margin_right_20 nicdark_border_radius_100_percentage " width="100" src="img/avatar/avatar-chef-4.jpg">
                                                            </div>

                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                                                <h3 class=""><strong>Sarah Hopiness</strong></h3>
                                                                <div class="nicdark_section nicdark_height_5"></div>
                                                                <h5 class="nicdark_color_grey">Web Design Teacher</h5>
                                                                <div class="nicdark_section nicdark_height_20"></div>

                                                                <div class="nicdark_section">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-facebook-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-twitter-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-color.svg">
                                                                    <img alt="" width="25" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-color.svg">
                                                                </div>

                                                            </div>

                                                        </div>
                                                
                                                        <div class="nicdark_section nicdark_height_20"></div>

                                                        <p class="nicdark_section">Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum. </p>
                                                        

                                                    </div>
                                                    <!--END teacher-->



                                                </div>


                                            </div>
                                            <div class="nicdark_section" id="tabs-4">


                                                <div class="nicdark_section">
                                    
        
                                                    <h3><strong>2 Comments</strong></h3>
                                                    <div class="nicdark_section nicdark_height_30"></div>
                                                    
                                                    
                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-2.jpg">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>John Doe</strong></span>September 4, 2015 at 1:24 pm</p>
                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>
                                                        <div class="nicdark_section nicdark_height_20"></div>

                                                        <div class="nicdark_section">
                                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">REPLY</a>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->

                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-2.jpg">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>John Doe</strong></span>September 4, 2015 at 1:24 pm</p>
                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>
                                                        <div class="nicdark_section nicdark_height_20"></div>

                                                        <div class="nicdark_section">
                                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">REPLY</a>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->



                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                    
                                                        <h3><strong>Leave a Comment</strong></h3>
                                                        <div class="nicdark_section nicdark_height_30"></div>
                                                        
                                                        


                                                        <div class="nicdark_section nicdark_box_sizing_border_box">

                                                            <!--form-->
                                                            <div class="nicdark_section">
                                                                <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Name">
                                                                </div>
                                                                <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_box_sizing_border_box nicdark_float_left">
                                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Surname">
                                                                </div>
                                                            </div>
                                                            <div class="nicdark_section">
                                                                <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
                                                                </div>
                                                                <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_box_sizing_border_box nicdark_float_left">
                                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Subject">
                                                                </div>
                                                            </div>
                                                            <div class="nicdark_section">
                                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                                                                    <textarea rows="7" class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Message"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="nicdark_section">
                                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                                                                    <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box  nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">SEND NOW</a>   
                                                                </div>
                                                            </div>
                                                            <!--form-->

                                                        </div>



                                                    </div>



                                                </div>


                                            </div>
                                            <div class="nicdark_section" id="tabs-5">
                                            


                                                <div class="nicdark_section">
                                    
        
                                                    <h3><strong>Course Reviews</strong></h3>
                                                    <div class="nicdark_section nicdark_height_30"></div>


                                                    <div class="nicdark_section">

                                                        <div class="nicdark_width_30_percentage nicdark_width_100_percentage_all_iphone nicdark_border_radius_3 nicdark_float_left nicdark_text_align_center nicdark_bg_greydark nicdark_padding_30 nicdark_box_sizing_border_box">

                                                            <h1 class="nicdark_font_size_70 nicdark_color_white"><strong>5</strong></h1>

                                                            <div class="nicdark_section nicdark_height_20"></div>

                                                            <div class="nicdark_section ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                            <p>3 Ratings</p>

                                                        </div>


                                                        <div class="nicdark_width_70_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_left_40 nicdark_padding_left_0_all_iphone nicdark_float_left nicdark_box_sizing_border_box">

                                                            <div class=" nicdark_border_radius_3 nicdark_section nicdark_border_1_solid_grey nicdark_padding_20 nicdark_box_sizing_border_box">
                                                                <table class="nicdark_section">
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>5 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_yellow nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">3</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>4 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>3 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>2 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>1 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                </table>
                                                            </div>

                                                        </div>



                                                    </div>


                                                    <div class="nicdark_section nicdark_height_30"></div>
                                                    
                                                    
                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-1.jpg">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>John Doe</strong></span></p>
                                                            
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->

                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-2.jpg">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>Nick Hope</strong></span></p>
                                                        
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->

                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-3.jpg">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>Jane Dark</strong></span></p>
                                                        
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->



                                                </div>



                                            </div>
                                            <div class="nicdark_section" id="tabs-6">



                                                <div class="nicdark_section">
                                    
        
                                                    <h3><strong>Course Attendees</strong></h3>
                                                    <div class="nicdark_section nicdark_height_30"></div>


                                                    <div class="nicdark_section">


                                                        <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_right_20 nicdark_padding_right_0_all_iphone nicdark_float_left nicdark_box_sizing_border_box">

                                                            <div class=" nicdark_border_radius_3 nicdark_section nicdark_border_1_solid_grey  nicdark_padding_30 nicdark_box_sizing_border_box">
                                                                <div class="nicdark_section nicdark_text_align_center   nicdark_box_sizing_border_box">

                                                                    <h1 class="nicdark_font_size_50 "><strong>30</strong></h1>

                                                                    <p>Attendees</p>

                                                                </div>
                                                            </div>

                                                        </div>


                                                        <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_right_20 nicdark_padding_left_0_all_iphone nicdark_padding_right_0_all_iphone nicdark_padding_left_20 nicdark_float_left nicdark_box_sizing_border_box">

                                                            <div class=" nicdark_border_radius_3 nicdark_section nicdark_border_1_solid_grey  nicdark_padding_30 nicdark_box_sizing_border_box">
                                                                <div class="nicdark_section nicdark_text_align_center   nicdark_box_sizing_border_box">

                                                                    <h1 class="nicdark_font_size_50 "><strong>10</strong></h1>

                                                                    <p>Available</p>

                                                                </div>
                                                            </div>

                                                        </div>


                                                        <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_left_20 nicdark_padding_left_0_all_iphone nicdark_float_left nicdark_box_sizing_border_box">

                                                            <div class=" nicdark_border_radius_3 nicdark_section nicdark_border_1_solid_grey  nicdark_padding_30 nicdark_box_sizing_border_box">
                                                                <div class="nicdark_section nicdark_text_align_center   nicdark_box_sizing_border_box">

                                                                    <h1 class="nicdark_font_size_50 "><strong>40</strong></h1>

                                                                    <p>Maximum</p>

                                                                </div>
                                                            </div>

                                                        </div>



                                                    </div>




                                                    <div class="nicdark_section nicdark_height_30"></div>
                                                    
                                                    
                                                    <!--START attendes-->
                                                    <div class="nicdark_section">
                                                    
                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-2.jpg">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Jane Goleman</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->

                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-3.jpg">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Jane Mgrayan</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->


                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-4.jpg">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Jack Johnson</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->


                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-5.jpg">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Nick Hopiness</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->


                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-6.jpg">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Steve Morgan</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->



                                                    </div>
                                                    <!--END attendes-->
                                                    



                                                </div>



                                            </div>

                                        </div>
                                        <!--END tab-->


                                    </div>
                                </div>


                                <div class="nicdark_section nicdark_height_50"></div>


                            </div>














                            <div class="nicdark_width_33_percentage nicdark_width_100_percentage_ipad_port nicdark_width_100_percentage_all_iphone nicdark_float_left">


                                <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">

                                    <div class="nicdark_section nicdark_height_60"></div>


                                    <div class="nicdark_section nicdark_text_align_center">
                                        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_color_white nicdark_bg_yellow nicdark_first_font nicdark_padding_8 nicdark_border_radius_3" href="#">ADD TO MY CALENDAR</a>
                                    </div>

                                    <div class="nicdark_section nicdark_height_25"></div>
                                
                                    <!--calendar-->
                                    <div class="nicdark_section nicdark_border_1_solid_grey">
                                        <div class="nicdark_datepicker"></div>
                                        <div class="nicdark_section nicdark_padding_10 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                                            <div class="nicdark_width_50_percentage nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                                                <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="checkout.php">BUY NOW</a>
                                            </div>   
                                            <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right nicdark_padding_10 nicdark_box_sizing_border_box">
                                                <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_color_white nicdark_bg_yellow nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="cart.php">ADD TO CART</a>
                                            </div>   
                                        </div>   
                                    </div>
                                    <!--calendar-->
                                   
                                   

                                    <div class="nicdark_section nicdark_height_13"></div>

                                   <table class="nicdark_section">
                                        <tbody>
                                            <tr class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-availability.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">27 Seats Available</h4></td>
                                            </tr>
                                            <tr class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20"><img alt="" class="" width="40" src="img/icons/icon-level.svg"></td>
                                                <td class="nicdark_padding_20"><h4 class=" nicdark_text_align_right">Level: Beginner</h4></td>
                                            </tr>
                                            <tr  class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-clock-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Duration: 8 Hours</h4></td>
                                            </tr>
                                            <tr  class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-pin-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Location: Sidney</h4></td>
                                            </tr>
                                            <tr>
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-card-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Price: 35 USD</h4></td>
                                            </tr>
                                        </tbody>
                                    </table>


                                    <div class="nicdark_section nicdark_height_20"></div>

                                    <div class="nicdark_section nicdark_bg_white nicdark_border_1_solid_grey">

                                          <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_bottom_1_solid_grey nicdark_text_align_center">
                                            
                                            
                                            <h3 class=""><strong>Question</strong></h3>
                                          </div>
                                          <div class="nicdark_section nicdark_padding_10 nicdark_box_sizing_border_box">
                                            
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Name">
                                                </div>
                                                
                                            </div>
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
                                                </div>
                                                
                                            </div>
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <textarea rows="4" class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="contact-1.php">SEND NOW</a>   
                                                </div>
                                            </div>

                                          </div>  

                                        </div>


                                </div>



                                <div class="nicdark_section nicdark_height_50"></div>


                            </div>
                    
                        

                        </div>
                        <!--end container-->

                    </div>








                    <!--START related products-->
                    <div class="nicdark_section nicdark_border_top_1_solid_grey">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">
                        
                            <div class="nicdark_section nicdark_height_50"></div>

                            <div class="grid grid_12">
                                <h2><strong>Related Products</strong></h2>
                            </div>

                        

                             <div class="nicdark_width_100_percentage">

    
    <!--START preview-->
    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_ipad_port nicdark_width_100_percentage_all_iphone nicdark_float_left">

        <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
            
            <!--start preview-->
            <div class="nicdark_section nicdark_border_1_solid_grey">
                
                <!--image-->
                <div class="nicdark_section nicdark_position_relative">
                    
                    <img alt="" class="nicdark_section" src="img/courses/img43.jpg">

                    <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                        
                        
                        <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                            <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                        </a>

                        <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                            <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                        </a>


                        <div class="nicdark_position_absolute nicdark_bottom_20">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                            </div>
                        </div>
                    </div>

                </div>
                <!--image-->


                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_white">
                
                    <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">Seo Course</a></h3>
                    <div class="nicdark_section nicdark_height_20"></div> 
                    <p><a class="" href="single-course.php">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue.</a></p>

                </div>

                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">

                    <div class="nicdark_width_33_percentage nicdark_display_none_all_responsive nicdark_width_50_percentage_responsive nicdark_float_left">
                        <div class="nicdark_display_table nicdark_float_left">
                            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="25" src="img/avatar/avatar-chef-1.jpg">
                            <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-teacher.php">John</a></p>
                        </div>
                    </div> 

                    <div class="nicdark_width_33_percentage nicdark_width_50_percentage_responsive nicdark_float_left">
                        <div class="nicdark_display_table nicdark_float_left">
                            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                            <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">221 Seats</a></p>
                        </div> 
                    </div> 

                    <div class="nicdark_width_33_percentage nicdark_width_50_percentage_responsive nicdark_float_left nicdark_text_align_right">
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">FREE</a>
                    </div> 
                    
                </div>



            </div>
            <!--start preview-->

        </div> 

    </div>
    <!--END preview-->




    <!--START preview-->
    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_ipad_port nicdark_width_100_percentage_all_iphone nicdark_float_left">

        <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
            
            <!--start preview-->
            <div class="nicdark_section nicdark_border_1_solid_grey">
                
                <!--image-->
                <div class="nicdark_section nicdark_position_relative">
                    
                    <img alt="" class="nicdark_section" src="img/courses/img2.jpg">

                    <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                        
                        
                        <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                            <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                        </a>

                        <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                            <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                        </a>


                        <div class="nicdark_position_absolute nicdark_bottom_20">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                            </div>
                        </div>
                    </div>

                </div>
                <!--image-->


                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_white">
                
                    <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">Photoshop Course</a></h3>
                    <div class="nicdark_section nicdark_height_20"></div> 
                    <p><a class="" href="single-course.php">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue.</a></p>

                </div>

                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">

                    <div class="nicdark_width_33_percentage nicdark_display_none_all_responsive nicdark_width_50_percentage_responsive nicdark_float_left">
                        <div class="nicdark_display_table nicdark_float_left">
                            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="25" src="img/avatar/avatar-chef-3.jpg">
                            <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-teacher.php">Mary</a></p>
                        </div>
                    </div> 

                    <div class="nicdark_width_33_percentage nicdark_width_50_percentage_responsive nicdark_float_left">
                        <div class="nicdark_display_table nicdark_float_left">
                            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                            <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">0 Seats</a></p>
                        </div> 
                    </div> 

                    <div class="nicdark_width_33_percentage nicdark_width_50_percentage_responsive nicdark_float_left nicdark_text_align_right">
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_orange nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">COMPLETED</a>
                    </div> 
                    
                </div>



            </div>
            <!--start preview-->

        </div> 

    </div>
    <!--END preview-->


    <!--START preview-->
    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_ipad_port nicdark_width_100_percentage_all_iphone nicdark_float_left">

        <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
            
            <!--start preview-->
            <div class="nicdark_section nicdark_border_1_solid_grey">
                
                <!--image-->
                <div class="nicdark_section nicdark_position_relative">
                    
                    <img alt="" class="nicdark_section" src="img/courses/img4.jpg">

                    <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                        
                        <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                            <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                        </a>

                        <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                            <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                        </a>

                        <div class="nicdark_position_absolute nicdark_bottom_20">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                            </div>
                        </div>
                    </div>

                </div>
                <!--image-->


                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_white">
                
                    <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">HTML Course</a></h3>
                    <div class="nicdark_section nicdark_height_20"></div> 
                    <p><a class="" href="single-course.php">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue.</a></p>

                </div>

                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">

                    <div class="nicdark_width_33_percentage nicdark_display_none_all_responsive nicdark_width_50_percentage_responsive nicdark_float_left">
                        <div class="nicdark_display_table nicdark_float_left">
                            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="25" src="img/avatar/avatar-chef-2.jpg">
                            <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-teacher.php">Lisa</a></p>
                        </div>
                    </div> 

                    <div class="nicdark_width_33_percentage nicdark_width_50_percentage_responsive nicdark_float_left">
                        <div class="nicdark_display_table nicdark_float_left">
                            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                            <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">221 Seats</a></p>
                        </div> 
                    </div> 

                    <div class="nicdark_width_33_percentage nicdark_width_50_percentage_responsive nicdark_float_left nicdark_text_align_right">
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">FREE</a>
                    </div>  
                    
                </div>



            </div>
            <!--start preview-->

        </div> 

    </div>
    <!--END preview-->

</div>
                    


                            <div class="nicdark_section nicdark_height_50"></div>


                        </div>
                        <!--end container-->

                    </div>
                    <!--END related products-->
                






                <div class="nicdark_section nicdark_bg_greydark">

    <div class="nicdark_section nicdark_height_50"></div>

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">
    
        
        <div class="grid grid_12 nicdark_text_align_center">
            
            <div class="nicdark_section">
                <a href="index.php"><img alt="" width="200" class="" src="img/logos/logo-elearning-white.svg"></a>
            </div>
            
            <div class="nicdark_section nicdark_height_20"></div>
            
            <div class="nicdark_display_inline_block">
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-facebook-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-twitter-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-youtube-circle.svg"></a>
            </div>

        </div>

    </div>
    <!--end container-->

    <div class="nicdark_section nicdark_height_50"></div>

</div>

<div class="nicdark_section nicdark_bg_greydark">

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_border_top_1_solid_greydark">
    
        
        <div class="grid grid_6 nicdark_text_align_center_responsive">
            <p class="nicdark_color_grey nicdark_font_size_14">© Copyright 2016 CleanThemes.net - e-Learning Theme</p>
        </div>

        <div class="grid grid_6 nicdark_text_align_right nicdark_text_align_center_responsive nicdark_border_top_1_solid_greydark_responsive nicdark_display_none_all_iphone">

            <div class="nicdark_navigation_copyright">
                <ul>
                    <li>
                        <a href="index.php">HOME</a>
                    </li>
                    <li>
                        <a href="about-us.php">ABOUT US</a>
                    </li>
                    <li>
                        <a href="services.php">SERVICES</a>
                    </li>
                    <li>
                        <a href="contact-1.php">CONTACT</a>
                    </li>
                </ul>
            </div>
            
        </div>

   
    </div>
    <!--end container-->

</div>








                


            </div>
        </div>


        
                <!--js-->
        <script src="js/nicdark_plugins.min.js" type="text/javascript"></script>


        <!--google analytics-->
        <script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-49425562-16', 'auto');
		  ga('send', 'pageview');

		</script>
		<!--google analytics-->


    </body>  
</html>