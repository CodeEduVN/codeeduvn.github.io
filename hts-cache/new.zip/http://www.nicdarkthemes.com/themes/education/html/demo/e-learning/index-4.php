<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<head>
 
    <meta charset="utf-8">  
    
    <title>Education - Learning Theme</title> <!--insert your title here-->  
    <meta name="description" content="Education - Learning theme for your business"> <!--insert your description here-->  
    <meta name="author" content="nicdark"> <!--insert your name here-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--meta responsive-->
    
    <!--START CSS--> 
    <link rel="stylesheet" href="css/nicdark_style.min.css"> <!--style-->

    <!--google fonts-->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

    <!--[if lt IE 9]>  
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>  
    <![endif]-->  

    <!--FAVICONS-->
    <link rel="shortcut icon" href="img/favicon/favicon.ico">
    <link rel="apple-touch-icon" href="img/favicon/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-touch-icon-114x114.png">
    <!--END FAVICONS-->
    
    
</head>  
    <body id="start_nicdark_framework">


        <!--START for demo-->
            <!--btn purchase-->
            <div class="nicdark_bg_greydark nicdark_z_index_99 nicdark_padding_1020 nicdark_border_radius_3 nicdark_position_fixed nicdark_bottom_20 nicdark_right_20">
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><img alt="" class="nicdark_float_left nicdark_margin_right_10" width="15" src="img/icons/icon-cart-white.svg"></a>
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><p class=" nicdark_first_font nicdark_line_height_17 nicdark_color_white nicdark_font_size_14 nicdark_float_left">Buy <strong>Education</strong> On</p></a>
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><img alt="" class="nicdark_float_left nicdark_margin_left_10" width="70" src="img/demo/envatologo.jpg"></a>
            </div>
            <!--END btn purchase-->
        <!--END for demo-->


        <!--START nicdark_site-->
        <div class="nicdark_site">

            <!--START nicdark_site_fullwidth-->
            <div class="nicdark_site_fullwidth nicdark_site_fullwidth_boxed nicdark_clearfix">



        <!--START search container-->
<div class="nicdark_display_table nicdark_transition_all_08_ease nicdark_navigation_5_search_content nicdark_bg_greydark_alpha_9 nicdark_position_fixed nicdark_width_100_percentage nicdark_height_100_percentage nicdark_z_index_1_negative nicdark_opacity_0">

    <!--close-->
    <div class="nicdark_cursor_zoom_out nicdark_navigation_5_close_search_content nicdark_width_100_percentage nicdark_height_100_percentage nicdark_position_absolute nicdark_z_index_1_negative"></div>


    <div class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_text_align_center">
        <div class="nicdark_width_700 nicdark_width_250_all_iphone nicdark_display_inline_block">
            <div class="nicdark_width_80_percentage nicdark_padding_5 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                <input class="nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0 nicdark_first_font nicdark_color_white nicdark_placeholder_color_white nicdark_font_size_30 nicdark_line_height_30" type="text" placeholder="Search">
            </div>
            <div class="nicdark_width_20_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                <a class="nicdark_width_55 nicdark_height_55 nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_bg_yellow nicdark_padding_15 nicdark_border_radius_3 " href="courses.php">
                    <img alt="" width="25" src="img/icons/icon-search-white.svg">
                </a>   
            </div>
        </div>
    </div>
            


</div>
<!--END search container-->




<!--START menu responsive-->
<div class="nicdark_navigation_5_sidebar_content nicdark_padding_40 nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_y_auto nicdark_transition_all_08_ease nicdark_bg_yellow nicdark_height_100_percentage nicdark_position_fixed nicdark_width_300 nicdark_right_300_negative nicdark_z_index_9">

    <img alt="" width="25" class="nicdark_close_navigation_5_sidebar_content nicdark_cursor_pointer nicdark_right_20 nicdark_top_20 nicdark_position_absolute" src="img/icons/icon-close-white.svg">



    <div class="nicdark_navigation_5_sidebar">
        <ul>
            <li>
                <a href="index.php">HOME</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="index.php">Home 1</a></li>
                    <li><a href="index-2.php">Home 2</a></li>
                    <li><a href="index-3.php">Home 3</a></li>
                    <li><a href="index-4.php">Home 4</a></li>
                    <li><a href="index-5.php">Home 5</a></li>
                </ul>

            </li>
            <li>
                <a href="courses.php">COURSES</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="courses.php">Archive</a></li>
                    <li><a href="single-course.php">Single Course</a></li>
                    <li>
                        <a href="account.php">User Pages</a>

                        <ul class="nicdark_sub_menu">
                            <li><a href="account.php">My Account</a></li> 
                            <li><a href="compare.php">Compare</a></li>
                        </ul>

                    </li> 
                    <li>
                        <a href="courses.php">Shop</a>

                        <ul class="nicdark_sub_menu">
                            <li><a href="cart.php">Cart</a></li>
                            <li><a href="checkout.php">Checkout</a></li>
                            <li><a href="thankyou.php">Thank You</a></li>
                        </ul>

                    </li> 
                </ul>

            </li>
            <li>
                <a href="teachers.php">TEACHERS</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="teachers.php">Archive</a></li>
                    <li><a href="single-teacher.php">Single Teacher</a></li>
                </ul>

            </li>
            <li>
                <a href="#">PAGES</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="single-course.php">Single Course</a></li>
                    <li><a href="single-teacher.php">Single Teacher</a></li>
                    <li><a href="contact-1.php">Contact</a></li>
                </ul>

            </li>
            <li>
                <a href="blog-standard.php">BLOG</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="blog-standard.php">Archive Standard</a></li>
                    <li><a href="blog-masonry.php">Archive Masonry</a></li>
                    <li><a href="single.php">Post Right Sidebar</a></li>
                    <li><a href="single-full-width.php">Post Full Width</a></li>
                    <li><a href="single-left-sidebar.php">Post Left Sidebar</a></li>
                </ul>

            </li>
            <li>
                <a href="contact-1.php">CONTACT</a>
            </li>
            
        </ul>

    </div>



</div>
<!--END menu responsive-->





<div class="nicdark_section">

    <div class="nicdark_section nicdark_bg_grey">

        


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="grid grid_6 nicdark_padding_botttom_10 nicdark_padding_top_10 nicdark_text_align_center_responsive">

              
                <div class="nicdark_navigation_top_header_5">
                    <ul>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 " width="15" src="img/icons/icon-world-grey.svg">
                            <a class=" nicdark_line_height_18" href="#">LANGUAGES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="#">English</a></li>
                                <li><a href="#">Russian</a></li>
                                <li><a href="#">Italian</a></li>
                            </ul>

                        </li>
                        <li>
                            
                            <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-share-grey.svg">
                            <a class=" nicdark_line_height_18" href="#">OUR SOCIAL</a>

                            <ul class="nicdark_sub_menu">
                                <li><a target="_blank" href="https://www.facebook.com/cleanthemeslab">Facebook</a></li>
                                <li><a target="_blank" href="https://dribbble.com/cleanthemeslab">Dribbble</a></li>
                                <li><a target="_blank" href="https://twitter.com/cleanthemeslab">Twitter</a></li>
                                <li><a target="_blank" href="https://www.instagram.com/cleanthemeslab/">Instagram</a></li>
                                <li><a target="_blank" href="https://www.behance.net/cleanthemeslab">Behance</a></li>
                            </ul>

                            <a target="_blank" href="https://www.facebook.com/cleanthemeslab"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-facebook-grey.svg"></a>
                            <a target="_blank" href="https://twitter.com/cleanthemeslab"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-twitter-grey.svg"></a>
                            <a target="_blank" href="#"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-linkedin-grey.svg"></a>
                            <a target="_blank" href="#"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-pinterest-grey.svg"></a>
                            <a target="_blank" href="https://www.instagram.com/cleanthemeslab/"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-instagram-grey.svg"></a>

                        </li>
                    </ul>
                </div>
                

            </div>


            <div class="grid grid_6 nicdark_text_align_right nicdark_border_top_1_solid_grey_responsive nicdark_text_align_center_responsive nicdark_padding_botttom_10 nicdark_padding_top_10">

              
                <div class="nicdark_navigation_top_header_5">
                    <ul>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 nicdark_float_left" width="15" src="img/icons/icon-user-grey.svg">
                            <a href="#">LOGIN</a>
                        </li>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 nicdark_float_left" width="15" src="img/icons/icon-login-grey.svg">
                            <a href="#">REGISTER</a>
                        </li>
                    </ul>
                </div>
                

            </div>


        </div>
        <!--end container-->

    </div>

</div>

<div class="nicdark_section nicdark_position_relative ">

    <div class="nicdark_section nicdark_position_absolute">

        


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_position_relative">

            <div class="grid grid_12 nicdark_display_none_all_responsive">

                <div class="nicdark_section nicdark_height_10"></div>

                <!--LOGO-->
                <a href="index.php"><img alt="" class="nicdark_position_absolute nicdark_left_15 nicdark_top_20" width="170" src="img/logos/logo-elearning-white.svg"></a>
              

                <!--right icons menu-->
                <div class="nicdark_float_right nicdark_width_100  nicdark_position_relative nicdark_height_25 nicdark_display_none_all_responsive">
                    
                    <a href="cart.php">
                        <img alt="" class="nicdark_opacity_05_hover nicdark_transition_all_08_ease nicdark_position_absolute nicdark_top_3_negative nicdark_left_0 nicdark_margin_left_20" width="25" src="img/icons/icon-cart-white.svg">
                    </a>

                    <a class="nicdark_bg_yellow nicdark_color_white nicdark_padding_5 nicdark_border_radius_100_percentage nicdark_font_size_8 nicdark_line_height_5 nicdark_position_absolute nicdark_left_0 nicdark_top_10_negative nicdark_margin_left_40" href="#">2</a>

                    <a class="nicdark_navigation_5_open_search_content" href="#"><img alt="" class="nicdark_opacity_05_hover nicdark_transition_all_08_ease nicdark_position_absolute nicdark_top_3_negative nicdark_right_0" width="25" src="img/icons/icon-search-white.svg"></a>

                </div>
                <!--right icons menu-->


                <div class="nicdark_navigation_5 nicdark_text_align_right nicdark_float_right nicdark_display_none_all_responsive">
                    <ul>
                        <li>
                            <a href="index.php">HOME</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="index.php">Home 1</a></li>
                                <li><a href="index-2.php">Home 2</a></li>
                                <li><a href="index-3.php">Home 3</a></li>
                                <li><a href="index-4.php">Home 4</a></li>
                                <li><a href="index-5.php">Home 5</a></li>
                            </ul>
                            
                        </li>
                        <li>
                            <a href="courses.php">COURSES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="courses.php">Archive</a></li>
                                <li><a href="single-course.php">Single Course</a></li>
                                <li>
                                    <a href="account.php">User Pages</a>

                                    <ul class="nicdark_sub_menu">
                                        <li><a href="account.php">My Account</a></li> 
                                        <li><a href="compare.php">Compare</a></li>
                                    </ul>

                                </li> 
                                <li>
                                    <a href="courses.php">Shop</a>

                                    <ul class="nicdark_sub_menu">
                                        <li><a href="cart.php">Cart</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="thankyou.php">Thank You</a></li>
                                    </ul>

                                </li> 
                            </ul>

                        </li>
                        <li>
                            <a href="teachers.php">TEACHERS</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="teachers.php">Archive</a></li>
                                <li><a href="single-teacher.php">Single Teacher</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="#">PAGES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li><a href="single-course.php">Single Course</a></li>
                                <li><a href="single-teacher.php">Single Teacher</a></li>
                                <li><a href="contact-1.php">Contact</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="blog-standard.php">BLOG</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="blog-standard.php">Archive Standard</a></li>
                                <li><a href="blog-masonry.php">Archive Masonry</a></li>
                                <li><a href="single.php">Post Right Sidebar</a></li>
                                <li><a href="single-full-width.php">Post Full Width</a></li>
                                <li><a href="single-left-sidebar.php">Post Left Sidebar</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="contact-1.php">CONTACT</a>
                        </li>
                        
                    </ul>

                </div> 


                

                <div class="nicdark_section nicdark_height_10"></div> 
                
            </div>




            <!--RESPONSIVE-->
            <div class="nicdark_width_50_percentage nicdark_text_align_center_all_iphone nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_display_none nicdark_display_block_responsive">
                <div class="nicdark_section nicdark_height_20"></div>
                <a href="index.php"><img alt="" width="170" class="" src="img/logos/logo-elearning-white.svg"></a>   
            </div>
            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_display_none nicdark_display_block_responsive">
                <div class="nicdark_section nicdark_height_20"></div>
                <div class="nicdark_float_right nicdark_width_100_percentage nicdark_text_align_right nicdark_text_align_center_all_iphone">
                    
                    
                    <a class="nicdark_open_navigation_5_sidebar_content" href="#">
                        <img alt="" class="nicdark_margin_right_20" width="25" src="img/icons/icon-menu-white.svg">
                    </a>

                    <div class="nicdark_position_relative nicdark_display_inline_block">
                        <a href="cart.php"><img alt="" width="25" src="img/icons/icon-cart-white.svg"></a> 
                        <a class="nicdark_bg_yellow nicdark_color_white nicdark_padding_5 nicdark_border_radius_100_percentage nicdark_font_size_8 nicdark_line_height_5 nicdark_position_absolute nicdark_left_0 nicdark_top_10_negative nicdark_margin_left_20" href="#">2</a>
                    </div>

                    <img alt="" class="nicdark_margin_left_20 nicdark_navigation_5_open_search_content" width="25" src="img/icons/icon-search-white.svg"> 

                </div>
            </div>
            <!--RESPONSIVE-->





        </div>
        <!--end container-->

    </div>

</div>
               
        <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img17.jpg);">

    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_5">

        
        <div class="nicdark_section nicdark_height_250"></div>

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">


            <div class="grid grid_8">

                
                
                <strong class="nicdark_color_white nicdark_font_size_70 nicdark_font_size_40_responsive nicdark_line_height_40_responsive nicdark_first_font nicdark_display_block">e-Learning</strong>

                <div class="nicdark_section nicdark_height_1"></div>

                <!--START typed words-->
                <div class="nicdark_section nicdark_display_none_all_responsive">
                    

                    <strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">Learning how to </strong>

                    <div class="nicdark_typed_strings">

                        <p><strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">make a Website</strong></p>
                        <p><strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">start a Startup</strong></p>

                    </div>
                    <span class="nicdark_typed nicdark_padding_botttom_5" style="white-space:pre;"></span>
                
                </div>
                <!--END typed words-->



                <div class="nicdark_section nicdark_height_30"></div>

                <p class="nicdark_color_white nicdark_font_size_20 nicdark_line_height_30">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue, dignissim id bibendum id, consequat et leo. Curabitur viverra tincidunt nulla nec tempor nullam augue augue.</p>
                
                <div class="nicdark_section nicdark_height_30"></div>

                <a class="nicdark_display_inline_block nicdark_margin_left_0 nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_border_2_solid_white nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_margin_10" href="about-us.php">ABOUT</a>
                <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_border_2_solid_white  nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_margin_10" href="courses.php">COURSES</a>

            </div>

        </div>
        <!--end container-->


        <div class="nicdark_section nicdark_height_250"></div>


    </div>

</div>

        <div class="nicdark_section nicdark_height_50"></div>


        <div class="nicdark_section">

    <div class="nicdark_container nicdark_clearfix">


        <div class="grid grid_12">

            <h1 class="nicdark_font_size_50"><strong>Our Courses</strong></h1>
            <div class="nicdark_section nicdark_height_10"></div>
            <h3 class=" nicdark_color_grey">The Best In Our School</h3>
        </div>


        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

            <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                
                <!--start preview-->
                <div class="nicdark_section nicdark_border_1_solid_grey">
                    
                    <!--image-->
                    <div class="nicdark_section nicdark_position_relative">
                        
                        <img alt="" class="nicdark_section" src="img/courses/img20.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                                            
                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                                <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                            </a>

                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                                <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                            </a>

                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                <h2 class="nicdark_color_white nicdark_display_none_all_iphone"><a class="nicdark_color_white nicdark_first_font" href="single-course.php">Web Design</a></h2>
                                <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div> 
                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                    <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                    <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                                </div>
                            </div>

                            <a href="single-teacher.php"><img alt="" class="nicdark_display_none_all_iphone nicdark_border_3_solid_white nicdark_border_radius_100_percentage nicdark_position_absolute nicdark_right_20 nicdark_bottom_35_negative" width="70" src="img/avatar/avatar-chef-4.jpg"></a>

                        </div>

                    </div>
                    <!--image-->


                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    
                        <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">Basic Course</a></h3>
                        <div class="nicdark_section nicdark_height_20"></div> 
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue, dignissim id bibendum id, consequat et leo. Curabitur viverra tincidunt nulla.</p>

                    </div>

                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                        
                        <div class="nicdark_width_33_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left nicdark_display_none_all_iphone">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-level.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">Medium Level</a></p>
                            </div> 
                        </div> 

                        <div class="nicdark_width_33_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">221 Seats</a></p>
                            </div> 
                        </div> 

                        <div class="nicdark_width_33_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left nicdark_text_align_right">
                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">FREE COURSE</a>
                        </div> 
                        
                    </div>



                </div>
                <!--start preview-->

            </div> 

        </div><div class="nicdark_width_50_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

            <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                
                <!--start preview-->
                <div class="nicdark_section nicdark_border_1_solid_grey">
                    
                    <!--image-->
                    <div class="nicdark_section nicdark_position_relative">
                        
                        <img alt="" class="nicdark_section" src="img/courses/img4.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                                            
                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                                <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                            </a>

                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                                <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                            </a>

                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                <h2 class="nicdark_color_white nicdark_display_none_all_iphone"><a class="nicdark_color_white nicdark_first_font" href="single-course.php">HTML Coding</a></h2>
                                <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div> 
                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                    <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">27/05/2017</p>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                    <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                                </div>
                            </div>

                            <a href="single-teacher.php"><img alt="" class="nicdark_display_none_all_iphone nicdark_border_3_solid_white nicdark_border_radius_100_percentage nicdark_position_absolute nicdark_right_20 nicdark_bottom_35_negative" width="70" src="img/avatar/avatar-chef-3.jpg"></a>

                        </div>

                    </div>
                    <!--image-->


                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    
                        <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">Advanced Level</a></h3>
                        <div class="nicdark_section nicdark_height_20"></div> 
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue, dignissim id bibendum id, consequat et leo. Curabitur viverra tincidunt nulla.</p>

                    </div>

                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                        
                        <div class="nicdark_width_33_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left nicdark_display_none_all_iphone">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-level.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">Advanced</a></p>
                            </div> 
                        </div> 

                        <div class="nicdark_width_33_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">15 Seats</a></p>
                            </div> 
                        </div> 

                        <div class="nicdark_width_33_percentage nicdark_width_50_percentage_all_iphone nicdark_float_left nicdark_text_align_right">
                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">USD 80</a>
                        </div> 
                        
                    </div>



                </div>
                <!--start preview-->

            </div> 

        </div>

        <div class="nicdark_width_100_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

              <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                    

                        <!--start preview-->
                        <div class="nicdark_section nicdark_border_1_solid_grey">
                    
                    <!--image-->
                    <div class="nicdark_section nicdark_position_relative">
                        
                        <img alt="" class="nicdark_section" src="img/courses/img2.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                            
                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                                <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                            </a>

                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                                <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                            </a>

                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                
                                <div class="nicdark_section nicdark_height_10"></div> 
                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                    <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                    <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!--image-->


                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    
                        <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">Photoshop Course</a></h3>
                         
                        

                    </div>

                    <div class="nicdark_section nicdark_padding_10_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                        
                        <div class="nicdark_width_50_percentage nicdark_float_left">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">0 Seats</a></p>
                            </div> 
                        </div> 

                         

                        <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_orange nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">COMPLETED</a>
                        </div> 
                        
                    </div>



                </div>
                        <!--start preview-->

                </div>   

            </div> 

            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

              <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                    
                    <!--start preview-->
                        <div class="nicdark_section nicdark_border_1_solid_grey">
                    
                    <!--image-->
                    <div class="nicdark_section nicdark_position_relative">
                        
                        <img alt="" class="nicdark_section" src="img/courses/img29.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                            
                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                                <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                            </a>

                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                                <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                            </a>

                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                
                                <div class="nicdark_section nicdark_height_10"></div> 
                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                    <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                    <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!--image-->


                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    
                        <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">Social Media Course</a></h3>
                         
                        

                    </div>

                    <div class="nicdark_section nicdark_padding_10_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                        
                        <div class="nicdark_width_50_percentage nicdark_float_left">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">65 Seats</a></p>
                            </div> 
                        </div> 

                         

                        <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">USD 70</a>
                        </div> 
                        
                    </div>



                </div>
                        <!--start preview-->

                </div>   

            </div>  

            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

              <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                    
                    <!--start preview-->
                        <div class="nicdark_section nicdark_border_1_solid_grey">
                    
                    <!--image-->
                    <div class="nicdark_section nicdark_position_relative">
                        
                        <img alt="" class="nicdark_section" src="img/courses/img3.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                            
                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                                <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                            </a>

                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                                <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                            </a>

                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                
                                <div class="nicdark_section nicdark_height_10"></div> 
                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                    <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                    <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!--image-->


                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    
                        <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">App Development</a></h3>
                         
                        

                    </div>

                    <div class="nicdark_section nicdark_padding_10_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                        
                        <div class="nicdark_width_50_percentage nicdark_float_left">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">73 Seats</a></p>
                            </div> 
                        </div> 

                         

                        <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">USD 150</a>
                        </div> 
                        
                    </div>



                </div>
                        <!--start preview-->

                </div>   

            </div>  

            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

              <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                    
                    <!--start preview-->
                        <div class="nicdark_section nicdark_border_1_solid_grey">
                    
                    <!--image-->
                    <div class="nicdark_section nicdark_position_relative">
                        
                        <img alt="" class="nicdark_section" src="img/courses/img1.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_2 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                            
                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Favorities" href="account.php#tabs-3">
                                <img alt="" class="nicdark_margin_right_60" width="25" src="img/icons/icon-heart-white.svg">
                            </a>

                            <a class="nicdark_tooltip_jquery nicdark_position_absolute nicdark_right_0" title="Add To Compare" href="compare.php">
                                <img alt="" class="nicdark_margin_right_20 nicdark_right_0" width="25" src="img/icons/icon-compare-white.svg">
                            </a>

                            <div class="nicdark_position_absolute nicdark_bottom_20">
                                
                                <div class="nicdark_section nicdark_height_10"></div> 
                                <div class="nicdark_display_table nicdark_float_left">
                                    <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-calendar.svg">
                                    <p class=" nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">21/12/2017</p>
                                    <img alt="" class="nicdark_margin_right_10 nicdark_margin_left_20 nicdark_display_table_cell nicdark_vertical_align_middle" width="20" src="img/icons/icon-clock.svg">
                                    <p class="nicdark_color_white nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_13">8 Hours</p>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!--image-->


                    <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    
                        <h3><a class="nicdark_color_greydark nicdark_first_font" href="single-course.php">e-Commerce Course</a></h3>
                         
                        

                    </div>

                    <div class="nicdark_section nicdark_padding_10_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_top_1_solid_grey">
                        
                        <div class="nicdark_width_50_percentage nicdark_float_left">
                            <div class="nicdark_display_table nicdark_float_left">
                                <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle" width="23" src="img/icons/icon-availability.svg">
                                <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15"><a href="single-course.php">6 Seats</a></p>
                            </div> 
                        </div> 

                         

                        <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-course.php">USD 50</a>
                        </div> 
                        
                    </div>



                </div>
                        <!--start preview-->

                </div>   

            </div>   

        </div>


    </div>
</div>

        <div class="nicdark_section nicdark_height_50"></div>


        <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img40.jpg);">
    <div class="nicdark_section nicdark_bg_greydark_alpha_6">

        
        <div class="nicdark_container nicdark_clearfix">


            <div class="nicdark_section nicdark_height_80"></div>


            <div class="grid grid_6 ">
        
                <!--START service-->
                <div class="nicdark_section nicdark_position_relative  nicdark_border_radius_3 nicdark_padding_20 nicdark_box_sizing_border_box">
                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-phone-white.svg">
                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                        <h2 class="nicdark_color_white"><strong>Free Call Support</strong></h2>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <p class="nicdark_color_white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_border_1_solid_white nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

                    </div>
                </div>
                <!--END services-->

            </div>


            <div class="grid grid_6 ">
        
                <!--START service-->
                <div class="nicdark_section nicdark_position_relative nicdark_border_radius_3 nicdark_padding_20 nicdark_box_sizing_border_box">
                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-percentage-white.svg">
                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                        <h2 class="nicdark_color_white"><strong>The Best Discount</strong></h2>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <p class="nicdark_color_white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_border_1_solid_white nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

                    </div>
                </div>
                <!--END services-->

            </div>


            <div class="nicdark_section nicdark_height_80"></div>

    
        </div>
        

    </div>
</div>

        <div class="nicdark_section nicdark_height_50"></div>


        <div class="nicdark_section ">

    <div class="nicdark_container nicdark_clearfix">

    

        <div class="grid grid_5 nicdark_text_align_right nicdark_text_align_center_responsive">
            <h1 class="nicdark_font_size_40 nicdark_line_height_50 nicdark_padding_10"><strong>Hello. Our school has been present for over 20 years in the market. We make the most of all our students.</strong></h1>
        </div>

        <div class="grid grid_7 ">
            

            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                <div class="nicdark_section nicdark_box_sizing_border_box">
                

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-4.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <h2 class="nicdark_color_white"><strong>Jane Grey</strong></h2>
                                <div class="nicdark_section nicdark_height_10"></div>
                                
                                
                                
                                <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>



                </div>
            </div>
            

            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                <div class="nicdark_section nicdark_box_sizing_border_box">
                

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-7.jpg">

                        <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <h2 class="nicdark_color_white"><strong>John Doe</strong></h2>
                                <div class="nicdark_section nicdark_height_10"></div>
                                
                                
                                
                                <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>



                </div>
            </div>


        </div>



    </div>

            
</div>            

        <div class="nicdark_section nicdark_height_50"></div>


        <div class="nicdark_section ">

    <div class="nicdark_container nicdark_clearfix">

        
        <div class="grid grid_4 ">
                            
                                
            <!--START price-->
            <div class="nicdark_section nicdark_box_sizing_border_box">
                
                <div class="nicdark_section nicdark_position_relative">
                        
                    <img alt="" class="nicdark_section" src="img/courses/img11.jpg">

                    <div class="nicdark_bg_greydark_alpha_6 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                        
                        <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                            

                            <h3 class="nicdark_color_white"><strong>Starter Plan</strong></h3>

                            <div class="nicdark_section nicdark_height_10"></div>
                            <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>

                            <div class="nicdark_text_align_center_all_iphone nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_box_sizing_border_box nicdark_padding_right_10 nicdark_text_align_right">
                                <h1 class="nicdark_color_white nicdark_font_size_60 nicdark_font_size_40_all_iphone nicdark_line_height_40_all_iphone"><strong><span class="nicdark_font_size_20 nicdark_margin_right_10">$</span>50</strong></h1>

                                <p class="nicdark_color_white ">/ Monthly</p>
                            </div>

                            <div class="nicdark_display_none_all_iphone  nicdark_width_50_percentage nicdark_float_left nicdark_box_sizing_border_box nicdark_padding_left_10 nicdark_text_align_left">
                                <div class="nicdark_section nicdark_height_15"></div>
                                <p class="nicdark_font_size_15 nicdark_line_height_20 nicdark_color_white">Lorem ipsum dolor sit amet.</p>
                            </div>
                            
                        </div>

                    </div>

                </div>



            </div>


            <div class="nicdark_section nicdark_border_1_solid_grey">
                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    

                    <table class="nicdark_section nicdark_text_align_center">
                        <tbody>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5 nicdark_padding_top_0"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="11" src="img/icons/icon-close-red.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr>
                                <td class="nicdark_padding_5 nicdark_padding_botttom_0"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="11" src="img/icons/icon-close-red.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="nicdark_section nicdark_height_20"></div>

                    <div class="nicdark_width_100_percentage  nicdark_box_sizing_border_box nicdark_float_left">
                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_greydark nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">REQUEST NOW</a>   
                    </div>


                </div>
                
            </div>
            <!--END price-->




        </div>

        <div class="grid grid_4 ">
        
            <!--START price-->
            <div class="nicdark_section nicdark_box_sizing_border_box">
                
                <div class="nicdark_section nicdark_position_relative">
                        
                    <img alt="" class="nicdark_section" src="img/courses/img14.jpg">

                    <div class="nicdark_bg_greydark_alpha_6 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                        
                        <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                            

                            <h3 class="nicdark_color_white"><strong>Basic Plan</strong></h3>

                            <div class="nicdark_section nicdark_height_10"></div>
                            <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>

                            <div class="nicdark_text_align_center_all_iphone nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_box_sizing_border_box nicdark_padding_right_10 nicdark_text_align_right">
                                <h1 class="nicdark_color_white nicdark_font_size_60 nicdark_font_size_40_all_iphone nicdark_line_height_40_all_iphone"><strong><span class="nicdark_font_size_20 nicdark_margin_right_10">$</span>100</strong></h1>

                                <p class="nicdark_color_white ">/ Monthly</p>
                            </div>

                            <div class="nicdark_display_none_all_iphone  nicdark_width_50_percentage nicdark_float_left nicdark_box_sizing_border_box nicdark_padding_left_10 nicdark_text_align_left">
                                <div class="nicdark_section nicdark_height_15"></div>
                                <p class="nicdark_font_size_15 nicdark_line_height_20 nicdark_color_white">Lorem ipsum dolor sit amet.</p>
                            </div>
                            
                        </div>

                    </div>

                </div>



            </div>


            <div class="nicdark_section nicdark_border_1_solid_grey">
                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    

                    <table class="nicdark_section nicdark_text_align_center">
                        <tbody>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5 nicdark_padding_top_0"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="11" src="img/icons/icon-close-red.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr>
                                <td class="nicdark_padding_5 nicdark_padding_botttom_0"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="11" src="img/icons/icon-close-red.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="nicdark_section nicdark_height_20"></div>

                    <div class="nicdark_width_100_percentage  nicdark_box_sizing_border_box nicdark_float_left">
                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_greydark nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">REQUEST NOW</a>   
                    </div>


                </div>
                
            </div>
            <!--END price-->

        </div>

        <div class="grid grid_4 ">
        
            <!--START price-->
            <div class="nicdark_section nicdark_box_sizing_border_box">
                
                <div class="nicdark_section nicdark_position_relative">
                        
                    <img alt="" class="nicdark_section" src="img/courses/img18.jpg">

                    <div class="nicdark_bg_greydark_alpha_6 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                        
                        <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                            

                            <h3 class="nicdark_color_white"><strong>Advanced Plan</strong></h3>

                            <div class="nicdark_section nicdark_height_10"></div>
                            <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>

                            <div class="nicdark_text_align_center_all_iphone nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_box_sizing_border_box nicdark_padding_right_10 nicdark_text_align_right">
                                <h1 class="nicdark_color_white nicdark_font_size_60 nicdark_font_size_40_all_iphone nicdark_line_height_40_all_iphone"><strong><span class="nicdark_font_size_20 nicdark_margin_right_10">$</span>150</strong></h1>

                                <p class="nicdark_color_white ">/ Monthly</p>
                            </div>

                            <div class="nicdark_display_none_all_iphone  nicdark_width_50_percentage nicdark_float_left nicdark_box_sizing_border_box nicdark_padding_left_10 nicdark_text_align_left">
                                <div class="nicdark_section nicdark_height_15"></div>
                                <p class="nicdark_font_size_15 nicdark_line_height_20 nicdark_color_white">Lorem ipsum dolor sit amet.</p>
                            </div>
                            
                        </div>

                    </div>

                </div>



            </div>


            <div class="nicdark_section nicdark_border_1_solid_grey">
                <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                    

                    <table class="nicdark_section nicdark_text_align_center">
                        <tbody>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5 nicdark_padding_top_0"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="13" src="img/icons/icon-check-green.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr class="nicdark_border_bottom_2_solid_grey">
                                <td class="nicdark_padding_5"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="11" src="img/icons/icon-close-red.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                            <tr>
                                <td class="nicdark_padding_5 nicdark_padding_botttom_0"><img alt="" class="nicdark_display_inline_block nicdark_margin_right_10" width="11" src="img/icons/icon-close-red.svg"><p class="nicdark_display_inline_block">Lorem ipsum dolor sit amet</p></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="nicdark_section nicdark_height_20"></div>

                    <div class="nicdark_width_100_percentage  nicdark_box_sizing_border_box nicdark_float_left">
                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_greydark nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">REQUEST NOW</a>   
                    </div>


                </div>
                
            </div>
            <!--END price-->

        </div>

                        
    </div>

</div>              


        <div class="nicdark_section nicdark_height_50"></div>


        <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img2.jpg);">

    <div class="nicdark_section nicdark_bg_greydark_alpha_4">


        <div class="nicdark_section nicdark_height_100"></div>


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">


            <div class="grid grid_6">
                <div class="nicdark_section nicdark_height_70"></div>
                <h1 class="nicdark_color_white nicdark_second_font">NEXT COURSE <span class="nicdark_border_bottom_4_solid_white">HTML BASICS</span></h1>
                <div class="nicdark_section nicdark_height_20"></div>
                <h1 class="nicdark_color_white nicdark_font_size_60"><strong><a class="nicdark_first_font nicdark_color_white" href="single-course.php">Available Now</a></strong></h1>
                <div class="nicdark_section nicdark_height_40"></div>


                <div class="nicdark_section">
                    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_text_align_center_all_iphone"> 
                        <div class=" nicdark_display_inline_block ">
                            <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_20_25">12</h1>
                            <h5 class="nicdark_bg_white nicdark_padding_5 nicdark_border_radius_3 nicdark_text_align_center">TEACHERS</h5>
                        </div>
                    </div> 
                    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_text_align_center_all_iphone"> 
                        <div class=" nicdark_display_inline_block ">
                            <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_20_25">50</h1>
                            <h5 class="nicdark_bg_white nicdark_padding_5 nicdark_border_radius_3 nicdark_text_align_center">ATTENDEES</h5>
                        </div>
                    </div> 
                    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_text_align_center_all_iphone"> 
                        <div class=" nicdark_display_inline_block ">
                            <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_20_25">15</h1>
                            <h5 class="nicdark_bg_white nicdark_padding_5 nicdark_border_radius_3 nicdark_text_align_center">DAYS</h5>
                        </div>
                    </div>    
                </div>

            </div>

            <div class="grid grid_1">
                <div class="nicdark_section nicdark_height_1"></div>
            </div>

            <div class="grid grid_5">
                
                <!--form-->
                <div class="nicdark_section nicdark_bg_white">

                  <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_bottom_1_solid_grey nicdark_text_align_center">
                    <h6 class="nicdark_second_font nicdark_bg_yellow nicdark_padding_5 nicdark_border_radius_3 nicdark_color_white nicdark_display_inline_block">LAST 7 SEATS</h6>
                    <div class="nicdark_section nicdark_height_5"></div>
                    <h1 class=""><strong>Register Now</strong></h1>
                  </div>
                  <div class="nicdark_section nicdark_padding_20_50 nicdark_box_sizing_border_box">
                    
                    <div class="nicdark_section">
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Name">
                        </div>
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Surname">
                        </div>
                    </div>
                    <div class="nicdark_section">
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
                        </div>
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Subject">
                        </div>
                    </div>
                    <div class="nicdark_section">
                        <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <textarea rows="4" class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Message"></textarea>
                        </div>
                    </div>
                    <div class="nicdark_section">
                        <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <a class="nicdark_bg_white_hover nicdark_color_green_hover nicdark_border_2_solid_green nicdark_transition_all_08_ease nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="contact-1.php">SEND NOW</a>   
                        </div>
                    </div>

                  </div>  

                </div>
                <!--form-->

            </div>


        </div>
        <!--end container-->

        <div class="nicdark_section nicdark_height_100"></div>


    </div>

</div> 


        <div class="nicdark_section">
    <div class="nicdark_section nicdark_bg_greydark nicdark_border_top_1_solid_greydark">

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="nicdark_section nicdark_height_30"></div>

            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo1.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo2.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo3.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo4.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo5.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo6.png">  
            </div>
            

            <div class="nicdark_section nicdark_height_30"></div>

    
        </div>
        <!--end container-->

    </div>
</div> 


        <div class="nicdark_section nicdark_bg_greydark">

    <div class="nicdark_section nicdark_height_50"></div>

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">
    
        
        <div class="grid grid_12 nicdark_text_align_center">
            
            <div class="nicdark_section">
                <a href="index.php"><img alt="" width="200" class="" src="img/logos/logo-elearning-white.svg"></a>
            </div>
            
            <div class="nicdark_section nicdark_height_20"></div>
            
            <div class="nicdark_display_inline_block">
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-facebook-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-twitter-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-youtube-circle.svg"></a>
            </div>

        </div>

    </div>
    <!--end container-->

    <div class="nicdark_section nicdark_height_50"></div>

</div>

<div class="nicdark_section nicdark_bg_greydark">

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_border_top_1_solid_greydark">
    
        
        <div class="grid grid_6 nicdark_text_align_center_responsive">
            <p class="nicdark_color_grey nicdark_font_size_14">© Copyright 2016 CleanThemes.net - e-Learning Theme</p>
        </div>

        <div class="grid grid_6 nicdark_text_align_right nicdark_text_align_center_responsive nicdark_border_top_1_solid_greydark_responsive nicdark_display_none_all_iphone">

            <div class="nicdark_navigation_copyright">
                <ul>
                    <li>
                        <a href="index.php">HOME</a>
                    </li>
                    <li>
                        <a href="about-us.php">ABOUT US</a>
                    </li>
                    <li>
                        <a href="services.php">SERVICES</a>
                    </li>
                    <li>
                        <a href="contact-1.php">CONTACT</a>
                    </li>
                </ul>
            </div>
            
        </div>

   
    </div>
    <!--end container-->

</div>

    </div>
</div>



        <!--js-->
        <script src="js/nicdark_plugins.min.js" type="text/javascript"></script>


        <!--google analytics-->
        <script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-49425562-16', 'auto');
		  ga('send', 'pageview');

		</script>
		<!--google analytics-->


    </body>  
</html>