<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<head>
 
    <meta charset="utf-8">  
    
    <title>Education - Learning Theme</title> <!--insert your title here-->  
    <meta name="description" content="Education - Learning theme for your business"> <!--insert your description here-->  
    <meta name="author" content="nicdark"> <!--insert your name here-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--meta responsive-->
    
    <!--START CSS--> 
    <link rel="stylesheet" href="css/nicdark_style.min.css"> <!--style-->

    <!--google fonts-->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

    <!--[if lt IE 9]>  
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>  
    <![endif]-->  

    <!--FAVICONS-->
    <link rel="shortcut icon" href="img/favicon/favicon.ico">
    <link rel="apple-touch-icon" href="img/favicon/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-touch-icon-114x114.png">
    <!--END FAVICONS-->
    
    
</head>  
    <body id="start_nicdark_framework">


        <!--START for demo-->
            <!--btn purchase-->
            <div class="nicdark_bg_greydark nicdark_z_index_99 nicdark_padding_1020 nicdark_border_radius_3 nicdark_position_fixed nicdark_bottom_20 nicdark_right_20">
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><img alt="" class="nicdark_float_left nicdark_margin_right_10" width="15" src="img/icons/icon-cart-white.svg"></a>
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><p class=" nicdark_first_font nicdark_line_height_17 nicdark_color_white nicdark_font_size_14 nicdark_float_left">Buy <strong>Education</strong> On</p></a>
                <a href="http://themeforest.net/item/education-education-learning-theme-for-education-courses-school-html/16350096?ref=nicdark"><img alt="" class="nicdark_float_left nicdark_margin_left_10" width="70" src="img/demo/envatologo.jpg"></a>
            </div>
            <!--END btn purchase-->
        <!--END for demo-->


        <!--START nicdark_site-->
        <div class="nicdark_site">

            <!--START nicdark_site_fullwidth-->
            <div class="nicdark_site_fullwidth nicdark_site_fullwidth_boxed nicdark_clearfix">








                <!--START search container-->
<div class="nicdark_display_table nicdark_transition_all_08_ease nicdark_navigation_2_search_content nicdark_bg_greydark_alpha_9 nicdark_position_fixed nicdark_width_100_percentage nicdark_height_100_percentage nicdark_z_index_1_negative nicdark_opacity_0">

    <!--close-->
    <div class="nicdark_cursor_zoom_out nicdark_navigation_2_close_search_content nicdark_width_100_percentage nicdark_height_100_percentage nicdark_position_absolute nicdark_z_index_1_negative"></div>


    <div class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_text_align_center">
        <div class="nicdark_width_700 nicdark_width_250_all_iphone nicdark_display_inline_block">
            <div class="nicdark_width_80_percentage nicdark_padding_5 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                <input class="nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0 nicdark_first_font nicdark_color_white nicdark_placeholder_color_white nicdark_font_size_30 nicdark_line_height_30" type="text" placeholder="Search">
            </div>
            <div class="nicdark_width_20_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                <a class="nicdark_width_55 nicdark_height_55 nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_bg_yellow nicdark_padding_15 nicdark_border_radius_3 " href="courses.php">
                    <img alt="" width="25" src="img/icons/icon-search-white.svg">
                </a>   
            </div>
        </div>
    </div>
            


</div>
<!--END search container-->




<!--START menu responsive-->
<div class="nicdark_navigation_2_sidebar_content nicdark_padding_40 nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_y_auto nicdark_transition_all_08_ease nicdark_bg_yellow nicdark_height_100_percentage nicdark_position_fixed nicdark_width_300 nicdark_right_300_negative nicdark_z_index_9">

    <img alt="" width="25" class="nicdark_close_navigation_2_sidebar_content nicdark_cursor_pointer nicdark_right_20 nicdark_top_20 nicdark_position_absolute" src="img/icons/icon-close-white.svg">



    <div class="nicdark_navigation_2_sidebar">
        <ul>
            <li>
                <a href="index.php">HOME</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="index.php">Home 1</a></li>
                    <li><a href="index-2.php">Home 2</a></li>
                    <li><a href="index-3.php">Home 3</a></li>
                    <li><a href="index-4.php">Home 4</a></li>
                    <li><a href="index-5.php">Home 5</a></li>
                </ul>

            </li>
            <li>
                <a href="courses.php">COURSES</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="courses.php">Archive</a></li>
                    <li><a href="single-course.php">Single Course</a></li>
                    <li>
                        <a href="account.php">User Pages</a>

                        <ul class="nicdark_sub_menu">
                            <li><a href="account.php">My Account</a></li> 
                            <li><a href="compare.php">Compare</a></li>
                        </ul>

                    </li> 
                    <li>
                        <a href="courses.php">Shop</a>

                        <ul class="nicdark_sub_menu">
                            <li><a href="cart.php">Cart</a></li>
                            <li><a href="checkout.php">Checkout</a></li>
                            <li><a href="thankyou.php">Thank You</a></li>
                        </ul>

                    </li> 
                </ul>

            </li>
            <li>
                <a href="teachers.php">TEACHERS</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="teachers.php">Archive</a></li>
                    <li><a href="single-teacher.php">Single Teacher</a></li>
                </ul>

            </li>
            <li>
                <a href="#">PAGES</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="single-course.php">Single Course</a></li>
                    <li><a href="single-teacher.php">Single Teacher</a></li>
                    <li><a href="contact-1.php">Contact</a></li>
                </ul>

            </li>
            <li>
                <a href="blog-standard.php">BLOG</a>

                <ul class="nicdark_sub_menu">
                    <li><a href="blog-standard.php">Archive Standard</a></li>
                    <li><a href="blog-masonry.php">Archive Masonry</a></li>
                    <li><a href="single.php">Post Right Sidebar</a></li>
                    <li><a href="single-full-width.php">Post Full Width</a></li>
                    <li><a href="single-left-sidebar.php">Post Left Sidebar</a></li>
                </ul>

            </li>
            <li>
                <a href="contact-1.php">CONTACT</a>
            </li>
            
        </ul>

    </div>



</div>
<!--END menu responsive-->





<div class="nicdark_section">

    <div class="nicdark_section nicdark_bg_greydark">

        


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="grid grid_6 nicdark_padding_botttom_10 nicdark_padding_top_10 nicdark_text_align_center_responsive">

              
                <div class="nicdark_navigation_top_header_2">
                    <ul>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 " width="15" src="img/icons/icon-world-grey.svg">
                            <a class=" nicdark_line_height_18" href="#">LANGUAGES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="#">English</a></li>
                                <li><a href="#">Russian</a></li>
                                <li><a href="#">Italian</a></li>
                            </ul>

                        </li>
                        <li>
                            
                            <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-share-grey.svg">
                            <a class=" nicdark_line_height_18" href="#">OUR SOCIAL</a>

                            <ul class="nicdark_sub_menu">
                                <li><a target="_blank" href="https://www.facebook.com/cleanthemeslab">Facebook</a></li>
                                <li><a target="_blank" href="https://dribbble.com/cleanthemeslab">Dribbble</a></li>
                                <li><a target="_blank" href="https://twitter.com/cleanthemeslab">Twitter</a></li>
                                <li><a target="_blank" href="https://www.instagram.com/cleanthemeslab/">Instagram</a></li>
                                <li><a target="_blank" href="https://www.behance.net/cleanthemeslab">Behance</a></li>
                            </ul>

                            <a target="_blank" href="https://www.facebook.com/cleanthemeslab"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-facebook-grey.svg"></a>
                            <a target="_blank" href="https://twitter.com/cleanthemeslab"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-twitter-grey.svg"></a>
                            <a target="_blank" href="#"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-linkedin-grey.svg"></a>
                            <a target="_blank" href="#"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-pinterest-grey.svg"></a>
                            <a target="_blank" href="https://www.instagram.com/cleanthemeslab/"><img alt="" class="nicdark_margin_left_10  nicdark_margin_top_2 nicdark_display_none_all_responsive" width="12" src="img/icons/icon-instagram-grey.svg"></a>

                        </li>
                    </ul>
                </div>
                

            </div>


            <div class="grid grid_6 nicdark_text_align_right nicdark_border_top_1_solid_greydark_responsive nicdark_text_align_center_responsive nicdark_padding_botttom_10 nicdark_padding_top_10">

              
                <div class="nicdark_navigation_top_header_2">
                    <ul>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 nicdark_float_left" width="15" src="img/icons/icon-user-grey.svg">
                            <a href="#">LOGIN</a>
                        </li>
                        <li>
                            <img alt="" class="nicdark_margin_right_10 nicdark_float_left" width="15" src="img/icons/icon-login-grey.svg">
                            <a href="#">REGISTER</a>
                        </li>
                    </ul>
                </div>
                

            </div>


        </div>
        <!--end container-->

    </div>

</div>

<div class="nicdark_section nicdark_position_relative ">

    <div class="nicdark_section nicdark_position_absolute">

        


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_position_relative">

            <div class="grid grid_12 nicdark_display_none_all_responsive">

                <div class="nicdark_section nicdark_height_10"></div>

                <!--LOGO-->
                <a href="index.php"><img alt="" class="nicdark_position_absolute nicdark_left_15 nicdark_top_20" width="170" src="img/logos/logo-elearning-white.svg"></a>
              

                <!--right icons menu-->
                <div class="nicdark_float_right nicdark_width_100  nicdark_position_relative nicdark_height_25 nicdark_display_none_all_responsive">
                    
                    <a href="cart.php">
                        <img alt="" class="nicdark_opacity_05_hover nicdark_transition_all_08_ease nicdark_position_absolute nicdark_top_3_negative nicdark_left_0 nicdark_margin_left_20" width="25" src="img/icons/icon-cart-white.svg">
                    </a>

                    <a class="nicdark_bg_yellow nicdark_color_white nicdark_padding_5 nicdark_border_radius_100_percentage nicdark_font_size_8 nicdark_line_height_5 nicdark_position_absolute nicdark_left_0 nicdark_top_10_negative nicdark_margin_left_40" href="#">2</a>

                    <a class="nicdark_navigation_2_open_search_content" href="#"><img alt="" class="nicdark_opacity_05_hover nicdark_transition_all_08_ease nicdark_position_absolute nicdark_top_3_negative nicdark_right_0" width="25" src="img/icons/icon-search-white.svg"></a>

                </div>
                <!--right icons menu-->


                <div class="nicdark_navigation_2 nicdark_text_align_right nicdark_float_right nicdark_display_none_all_responsive">
                    <ul>
                        <li>
                            <a href="index.php">HOME</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="index.php">Home 1</a></li>
                                <li><a href="index-2.php">Home 2</a></li>
                                <li><a href="index-3.php">Home 3</a></li>
                                <li><a href="index-4.php">Home 4</a></li>
                                <li><a href="index-5.php">Home 5</a></li>
                            </ul>
                            
                        </li>
                        <li>
                            <a href="courses.php">COURSES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="courses.php">Archive</a></li>
                                <li><a href="single-course.php">Single Course</a></li>
                                <li>
                                    <a href="account.php">User Pages</a>

                                    <ul class="nicdark_sub_menu">
                                        <li><a href="account.php">My Account</a></li> 
                                        <li><a href="compare.php">Compare</a></li>
                                    </ul>

                                </li> 
                                <li>
                                    <a href="courses.php">Shop</a>

                                    <ul class="nicdark_sub_menu">
                                        <li><a href="cart.php">Cart</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="thankyou.php">Thank You</a></li>
                                    </ul>

                                </li> 
                            </ul>

                        </li>
                        <li>
                            <a href="teachers.php">TEACHERS</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="teachers.php">Archive</a></li>
                                <li><a href="single-teacher.php">Single Teacher</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="#">PAGES</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li><a href="single-course.php">Single Course</a></li>
                                <li><a href="single-teacher.php">Single Teacher</a></li>
                                <li><a href="contact-1.php">Contact</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="blog-standard.php">BLOG</a>

                            <ul class="nicdark_sub_menu">
                                <li><a href="blog-standard.php">Archive Standard</a></li>
                                <li><a href="blog-masonry.php">Archive Masonry</a></li>
                                <li><a href="single.php">Post Right Sidebar</a></li>
                                <li><a href="single-full-width.php">Post Full Width</a></li>
                                <li><a href="single-left-sidebar.php">Post Left Sidebar</a></li>
                            </ul>

                        </li>
                        <li>
                            <a href="contact-1.php">CONTACT</a>
                        </li>
                        
                    </ul>

                </div> 


                

                <div class="nicdark_section nicdark_height_10"></div> 
                
            </div>




            <!--RESPONSIVE-->
            <div class="nicdark_width_50_percentage nicdark_text_align_center_all_iphone nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_display_none nicdark_display_block_responsive">
                <div class="nicdark_section nicdark_height_20"></div>
                <a href="index.php"><img alt="" width="170" class="" src="img/logos/logo-elearning-white.svg"></a>   
            </div>
            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_display_none nicdark_display_block_responsive">
                <div class="nicdark_section nicdark_height_20"></div>
                <div class="nicdark_float_right nicdark_width_100_percentage nicdark_text_align_right nicdark_text_align_center_all_iphone">
                    
                    
                    <a class="nicdark_open_navigation_2_sidebar_content" href="#">
                        <img alt="" class="nicdark_margin_right_20" width="25" src="img/icons/icon-menu-white.svg">
                    </a>

                    <div class="nicdark_position_relative nicdark_display_inline_block">
                        <a href="cart.php"><img alt="" width="25" src="img/icons/icon-cart-white.svg"></a> 
                        <a class="nicdark_bg_yellow nicdark_color_white nicdark_padding_5 nicdark_border_radius_100_percentage nicdark_font_size_8 nicdark_line_height_5 nicdark_position_absolute nicdark_left_0 nicdark_top_10_negative nicdark_margin_left_20" href="#">2</a>
                    </div>

                    <img alt="" class="nicdark_margin_left_20 nicdark_navigation_2_open_search_content" width="25" src="img/icons/icon-search-white.svg"> 

                </div>
            </div>
            <!--RESPONSIVE-->





        </div>
        <!--end container-->

    </div>

</div>





                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img40.jpg);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">Cart</strong>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>



                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">


                            
                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Courses</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Cart</a>
                            


                        </div>

                
                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_8">

                            <div class="nicdark_section nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_x_auto nicdark_cursor_move_responsive">

                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20 nicdark_width_25_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Product</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_30_percentage">   
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_15_percentage">  
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_10_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Qnt</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_15_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Total</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_5_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img1.jpg">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>e-Commerce</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">  
                                                <p>$ 50,00</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <input class="nicdark_color_greydark nicdark_first_font nicdark_text_align_center nicdark_font_size_20 nicdark_bg_white nicdark_border_bottom_2_solid_grey nicdark_border_0 nicdark_padding_right_0 nicdark_padding_left_0" type="number" min="0" max="10" step="1" value="1">  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 50,00</p>    
                                            </td>
                                            <td class="nicdark_padding_20">   
                                                <img alt="" width="15" src="img/icons/icon-remove-red.svg">
                                            </td>
                                        </tr>

                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img2.jpg">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Photoshop Course</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">  
                                                <p>$ 50,00</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <input class="nicdark_color_greydark nicdark_first_font nicdark_text_align_center nicdark_font_size_20 nicdark_bg_white nicdark_border_bottom_2_solid_grey nicdark_border_0 nicdark_padding_right_0 nicdark_padding_left_0" type="number" min="0" max="10" step="1" value="1">  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 50,00</p>    
                                            </td>
                                            <td class="nicdark_padding_20">   
                                                <img alt="" width="15" src="img/icons/icon-remove-red.svg">
                                            </td>
                                        </tr>

                                        <tr class="">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img3.jpg">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>App Development</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">  
                                                <p>$ 90,00</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <input class="nicdark_color_greydark nicdark_first_font nicdark_text_align_center nicdark_font_size_20 nicdark_bg_white nicdark_border_bottom_2_solid_grey nicdark_border_0 nicdark_padding_right_0 nicdark_padding_left_0" type="number" min="0" max="10" step="1" value="1">  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 80,00</p>    
                                            </td>
                                            <td class="nicdark_padding_20">   
                                                <img alt="" width="15" src="img/icons/icon-remove-red.svg">
                                            </td>
                                        </tr>


                                    </tbody>
                                </table>

                            </div>


                            <div class="nicdark_section nicdark_height_50"></div>


                            <!--START coupon-->
                            <div class="nicdark_section nicdark_border_3_dashed_grey nicdark_padding_30 nicdark_box_sizing_border_box">
                                
                                <div class="nicdark_section">
                                    <div class="nicdark_width_15_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <div class="nicdark_section nicdark_height_5"></div>
                                    </div>
                                    <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Insert Coupon Code">
                                    </div>
                                    <div class="nicdark_width_20_percentage nicdark_width_100_percentage_all_iphone nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_width_100_percentage" href="#">APPLY</a>
                                    </div>
                                    <div class="nicdark_width_15_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <div class="nicdark_section nicdark_height_5"></div>
                                    </div>
                                </div>   

                            </div>
                            <!--END coupon-->


                        </div>

                        <div class="grid grid_4">

                            <div class="nicdark_section nicdark_bg_grey nicdark_border_1_solid_grey nicdark_padding_20 nicdark_box_sizing_border_box">


                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20 nicdark_width_50_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">TOTALS</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_50_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                       <tr class="">
                                            <td class="nicdark_padding_20">  
                                                <p>Subtotal</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 50,00</p>    
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">  
                                                <p>Method</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">Paypal</p>    
                                            </td>
                                        </tr>
                                        <tr class="">
                                            <td class="nicdark_padding_20">  
                                                <p>Total</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <h2><strong>$ 50,00</strong></h2>    
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>  


                                <div class="nicdark_section">
                                    <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_yellow nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">UPDATE CART</a>   
                                    </div>

                                    <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="checkout.php">GO TO CHECKOUT</a>   
                                    </div>
                                </div> 


                            </div>
                        
                        </div>

                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_50"></div>



                <div class="nicdark_section nicdark_bg_greydark">

    <div class="nicdark_section nicdark_height_50"></div>

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">
    
        
        <div class="grid grid_12 nicdark_text_align_center">
            
            <div class="nicdark_section">
                <a href="index.php"><img alt="" width="200" class="" src="img/logos/logo-elearning-white.svg"></a>
            </div>
            
            <div class="nicdark_section nicdark_height_20"></div>
            
            <div class="nicdark_display_inline_block">
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-facebook-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-twitter-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-circle.svg"></a>
                <a href="index.php"><img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-youtube-circle.svg"></a>
            </div>

        </div>

    </div>
    <!--end container-->

    <div class="nicdark_section nicdark_height_50"></div>

</div>

<div class="nicdark_section nicdark_bg_greydark">

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_border_top_1_solid_greydark">
    
        
        <div class="grid grid_6 nicdark_text_align_center_responsive">
            <p class="nicdark_color_grey nicdark_font_size_14">© Copyright 2016 CleanThemes.net - e-Learning Theme</p>
        </div>

        <div class="grid grid_6 nicdark_text_align_right nicdark_text_align_center_responsive nicdark_border_top_1_solid_greydark_responsive nicdark_display_none_all_iphone">

            <div class="nicdark_navigation_copyright">
                <ul>
                    <li>
                        <a href="index.php">HOME</a>
                    </li>
                    <li>
                        <a href="about-us.php">ABOUT US</a>
                    </li>
                    <li>
                        <a href="services.php">SERVICES</a>
                    </li>
                    <li>
                        <a href="contact-1.php">CONTACT</a>
                    </li>
                </ul>
            </div>
            
        </div>

   
    </div>
    <!--end container-->

</div>








                


            </div>
        </div>


        
                <!--js-->
        <script src="js/nicdark_plugins.min.js" type="text/javascript"></script>


        <!--google analytics-->
        <script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-49425562-16', 'auto');
		  ga('send', 'pageview');

		</script>
		<!--google analytics-->


    </body>  
</html>